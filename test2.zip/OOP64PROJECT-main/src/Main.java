public class Main {
    public static void main(String[] args) {
        JframeStart k = new JframeStart();
    }
}
